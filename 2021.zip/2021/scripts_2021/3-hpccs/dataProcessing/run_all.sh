#!/bin/bash

script_path=/cygdrive/c/Users/pinic/Documents/REHS21/CCS/scripts/3-hpccs/dataProcessing

${script_path}/run_data_process.sh model1 B3LYP B3LYP_model1
${script_path}/run_data_process.sh model1 D3BJ D3BJ_model1
${script_path}/run_data_process.sh model4 B3LYP B3LYP_model4
${script_path}/run_data_process.sh model4 D3BJ D3BJ_model4