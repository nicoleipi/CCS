#!/bin/bash

script_path=/cygdrive/c/Users/pinic/Documents/REHS21/CCS/scripts/2-boltz-avg

${script_path}/addBoltzAvg2energy.sh /cygdrive/c/Users/pinic/Documents/REHS21/CCS/data/model1/B3LYP
${script_path}/addBoltzAvg2energy.sh /cygdrive/c/Users/pinic/Documents/REHS21/CCS/data/model4/B3LYP
${script_path}/addBoltzAvg2energy.sh /cygdrive/c/Users/pinic/Documents/REHS21/CCS/data/model1/D3BJ
${script_path}/addBoltzAvg2energy.sh /cygdrive/c/Users/pinic/Documents/REHS21/CCS/data/model4/D3BJ