#!/bin/bash

./run_Boltzmann_weighted.sh B3LYP_model1 B3LYP_model1_data model1_B3LYP
./run_Boltzmann_weighted.sh B3LYP_model4 B3LYP_model4_data model4_B3LYP
./run_Boltzmann_weighted.sh D3BJ_model1 D3BJ_model1_data model1_D3BJ
./run_Boltzmann_weighted.sh D3BJ_model4 D3BJ_model4_data model4_D3BJ