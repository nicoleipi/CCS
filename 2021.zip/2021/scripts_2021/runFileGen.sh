#!/bin/bash

python3 fileGen.py -i /aerosol/users/nicole/CCS/test/molecule1 -c 0 -s 1 -o /aerosol/users/nicole/CCS/test_out/molecule1
python3 fileGen.py -i /aerosol/users/nicole/CCS/test/molecule4 -c 1 -s 1 -o /aerosol/users/nicole/CCS/test_out/molecule4

